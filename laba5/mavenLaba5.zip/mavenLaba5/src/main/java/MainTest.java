import StudyGroup.StudyGroup;
import commands.Invoker;
import util.StudyGroupParser;

import java.io.File;
import java.util.List;
import java.util.Scanner;

public class MainTest {
    static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        // Получаем путь к файлу из переменной окружения
        String path = System.getenv("STUDY_GROUP_FILE");
        if (path == null || path.isEmpty()) {
            System.out.println("Ошибка: переменная окружения STUDY_GROUP_FILE не установлена.");
            return;
        }

        File file = new File(path);

        // Проверяем, существует ли файл
        if (!file.exists()) {
            System.out.println("Ошибка: файл по пути '" + path + "' не существует.");
            return;
        }

        List<StudyGroup> studyGroups = StudyGroupParser.loadFromFile(file);

        if (studyGroups == null || studyGroups.isEmpty()) {
            System.out.println("Ошибка: не удалось загрузить данные из файла.");
            return;
        }

        Invoker invoker = new Invoker(studyGroups);

        while (true) {
            System.out.print("Введите команду: ");
            String command = in.nextLine();
            invoker.invoke(command);
        }
    }
}
